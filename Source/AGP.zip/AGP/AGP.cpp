// Copyright Epic Games, Inc. All Rights Reserved.

#include "AGP.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, AGP, "AGP" );
