// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyCharacter.h"
#include "EngineUtils.h"
#include "HealthComponent.h"
#include "PlayerCharacter.h"
#include "../Pickups/WeaponComponent.h"
#include "AGP/Pathfinding/PathfindingSubsystem.h"
#include "Perception/PawnSensingComponent.h"

// Sets default values
AEnemyCharacter::AEnemyCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	PawnSensingComponent = CreateDefaultSubobject<UPawnSensingComponent>("Pawn Sensing Component");
}

// Called when the game starts or when spawned
void AEnemyCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (GetLocalRole() == ROLE_Authority)
	{
		PathfindingSubsystem = GetWorld()->GetSubsystem<UPathfindingSubsystem>();
		if (PathfindingSubsystem)
		{
			CurrentPath = PathfindingSubsystem->GetRandomPath(GetActorLocation());
		} else
		{
			UE_LOG(LogTemp, Error, TEXT("Unable to find the PathfindingSubsystem"))
		}
		if (PawnSensingComponent)
		{
			PawnSensingComponent->OnSeePawn.AddDynamic(this, &AEnemyCharacter::OnSensedPawn);
		}
	}
}

void AEnemyCharacter::MoveAlongPath()
{
	// Execute the path. Should be called each tick.

	// If the path is empty do nothing.
	if (CurrentPath.IsEmpty()) return;
	
	// 1. Move towards the current stage of the path.
	//		a. Calculate the direction from the current position to the target of the current stage of the path.
	FVector MovementDirection = CurrentPath[CurrentPath.Num()-1] - GetActorLocation();
	MovementDirection.Normalize();
	//		b. Apply movement in that direction.
	AddMovementInput(MovementDirection);
	// 2. Check if it is close to the current stage of the path then pop it off.
	if (FVector::Distance(GetActorLocation(), CurrentPath[CurrentPath.Num() - 1]) < PathfindingError)
	{
		CurrentPath.Pop();
	}
}

void AEnemyCharacter::TickPatrol()
{
	if (CurrentPath.IsEmpty())
	{
		CurrentPath = PathfindingSubsystem->GetRandomPath(GetActorLocation());
	}
	MoveAlongPath();
}

void AEnemyCharacter::TickEngage()
{
	if (!SensedCharacter) return;
	
	if (CurrentPath.IsEmpty())
	{
		CurrentPath = PathfindingSubsystem->GetPath(GetActorLocation(), SensedCharacter->GetActorLocation());
	}
	MoveAlongPath();

	if (WeaponComponent)
	{
		if (WeaponComponent -> Ammo > 0)
		{
			Fire(SensedCharacter->GetActorLocation());
		}
		else if (WeaponComponent -> Ammo <= 0 && OuttaAmmo == false)
		{
			OuttaAmmo = true;
			WeaponComponent -> Reload();
		}
		if (WeaponComponent -> CurrentReloadTime > WeaponComponent -> WeaponStats.ReloadTime)
		{
			OuttaAmmo = false;
		}
	}
}

void AEnemyCharacter::TickEvade()
{
	// Find the player and return if it can't find it.
	if (!SensedCharacter) return;

	if (CurrentPath.IsEmpty())
	{
		CurrentPath = PathfindingSubsystem->GetPathAway(GetActorLocation(), SensedCharacter->GetActorLocation());
	}
	MoveAlongPath();
}

void AEnemyCharacter::OnSensedPawn(APawn* SensedActor)
{
	if (APlayerCharacter* Player = Cast<APlayerCharacter>(SensedActor))
	{
		SensedCharacter = Player;
		UE_LOG(LogTemp, Display, TEXT("Sensed Player"))
	}
}

void AEnemyCharacter::UpdateSight()
{
	if (!SensedCharacter) return;
	if (PawnSensingComponent)
	{
		if (!PawnSensingComponent->HasLineOfSightTo(SensedCharacter))
		{
			SensedCharacter = nullptr;
			UE_LOG(LogTemp, Display, TEXT("Lost Player"))
		}
	}
}


// Called every frame
void AEnemyCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if(GetLocalRole() == ROLE_Authority)
	{
		UpdateSight();
		
		switch(CurrentState)
		{
		case EEnemyState::Patrol:
			TickPatrol();
			if (SensedCharacter)
			{
				if (HealthComponent->GetCurrentHealthPercentage() >= 0.4f)
				{
					CurrentState = EEnemyState::Engage;
				} else
				{
					CurrentState = EEnemyState::Evade;
				}
				CurrentPath.Empty();
			}
			break;
		case EEnemyState::Engage:
			TickEngage();
			if (HealthComponent->GetCurrentHealthPercentage() < 0.4f)
			{
				CurrentPath.Empty();
				CurrentState = EEnemyState::Evade;
			} else if (!SensedCharacter)
			{
				CurrentState = EEnemyState::Patrol;
			}
			break;
		case EEnemyState::Evade:
			TickEvade();
			if (HealthComponent->GetCurrentHealthPercentage() >= 0.4f)
			{
				CurrentPath.Empty();
				CurrentState = EEnemyState::Engage;
			} else if (!SensedCharacter)
			{
				CurrentState = EEnemyState::Patrol;
			}
			break;
		}		
	}w
}

// Called to bind functionality to input
void AEnemyCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

APlayerCharacter* AEnemyCharacter::FindPlayer() const
{
	APlayerCharacter* Player = nullptr;
	for (TActorIterator<APlayerCharacter> It(GetWorld()); It; ++It)
	{
		Player = *It;
		break;
	}
	if (!Player)
	{
		UE_LOG(LogTemp, Error, TEXT("Unable to find the Player Character in the world."))
	}
	return Player;
}

/*
void AEnemyCharacter::DoEverything()
{
	if (GetNetMode() == ROLE_Authority)
	{
		ServerDoEverything_Implementation();
	}
}

void AEnemyCharacter::DoEverythingImplementation()
{
	MoveAlongPath();
}

void AEnemyCharacter::ServerDoEverything_Implementation()
{
	DoEverythingImplementation();
}
*/



